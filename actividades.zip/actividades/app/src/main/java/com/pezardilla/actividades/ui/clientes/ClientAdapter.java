package com.pezardilla.actividades.ui.clientes;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.pezardilla.actividades.R;
import com.pezardilla.actividades.model.Client;

import java.text.DateFormat;
import java.util.ArrayList;
import java.util.List;

public class ClientAdapter extends RecyclerView.Adapter<ClientAdapter.ClientViewHolder> {
    private List<Client> clients = new ArrayList<>();

    /** Constructor vacío o con lista inicial */
    public ClientAdapter() { }

    public ClientAdapter(List<Client> initialClients) {
        this.clients = initialClients;
    }

    @NonNull
    @Override
    public ClientViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // Inflamos el item_client.xml
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_client, parent, false);
        return new ClientViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull ClientViewHolder holder, int position) {
        Client client = clients.get(position);

        holder.tvName.setText(client.getName());
        holder.tvEmail.setText(client.getEmail());
        holder.tvPhone.setText(client.getPhone() != null ? client.getPhone() : "");

        // Formatear fecha de nacimiento si existe
        if (client.getBirthDate() != null) {
            String fecha = DateFormat.getDateInstance(DateFormat.SHORT)
                    .format(client.getBirthDate());
            holder.tvBirth.setText(fecha);
        } else {
            holder.tvBirth.setText("");
        }
    }

    @Override
    public int getItemCount() {
        return clients.size();
    }

    /** Llama a este método para actualizar la lista en tiempo real */
    public void updateData(List<Client> newClients) {
        this.clients = newClients;
        notifyDataSetChanged();
    }

    /** ViewHolder que contiene referencias a cada TextView del item */
    static class ClientViewHolder extends RecyclerView.ViewHolder {
        final TextView tvName;
        final TextView tvEmail;
        final TextView tvPhone;
        final TextView tvBirth;

        public ClientViewHolder(@NonNull View itemView) {
            super(itemView);
            tvName  = itemView.findViewById(R.id.tvClientName);
            tvEmail = itemView.findViewById(R.id.tvClientEmail);
            tvPhone = itemView.findViewById(R.id.tvClientPhone);
            tvBirth = itemView.findViewById(R.id.tvClientBirth);
        }
    }
}