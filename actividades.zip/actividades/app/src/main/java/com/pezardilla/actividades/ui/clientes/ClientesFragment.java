package com.pezardilla.actividades.ui.clientes;


import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QuerySnapshot;
import com.pezardilla.actividades.R;
import com.pezardilla.actividades.databinding.FragmentClientesBinding;
import com.pezardilla.actividades.model.Client;

import java.util.ArrayList;
import java.util.List;

public class ClientesFragment extends Fragment {
    private FragmentClientesBinding binding;
    private ClientAdapter adapter;
    private FirebaseFirestore db;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentClientesBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        // 1) Prepara RecyclerView y Adapter
        adapter = new ClientAdapter(new ArrayList<>());
        binding.rvClientes.setLayoutManager(new LinearLayoutManager(requireContext()));
        binding.rvClientes.setAdapter(adapter);

        // 2) Instancia Firestore
        db = FirebaseFirestore.getInstance();

        // 3) Listener de búsqueda: vuelve a cargar la lista en cada cambio
        binding.etSearch.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int st, int c, int a) {}
            @Override public void onTextChanged(CharSequence s, int st, int b, int c) {
                fetchClients(s.toString().trim());
            }
            @Override public void afterTextChanged(Editable s) {}
        });

        // 4) Carga inicial sin filtro
        fetchClients("");
    }

    private void fetchClients(String filter) {
        Query query = db.collection("clientes")
                .orderBy("name", Query.Direction.ASCENDING);

        if (!filter.isEmpty()) {
            // Filtrado “starts with”
            query = query
                    .whereGreaterThanOrEqualTo("name", filter)
                    .whereLessThanOrEqualTo("name", filter + '\uf8ff');
        }

        query.get()
                .addOnSuccessListener(this::onClientsLoaded)
                .addOnFailureListener(e ->
                        Toast.makeText(requireContext(),
                                "Error cargando clientes: " + e.getMessage(),
                                Toast.LENGTH_LONG).show()
                );
    }

    private void onClientsLoaded(QuerySnapshot snap) {
        List<Client> list = new ArrayList<>();
        for (var doc : snap.getDocuments()) {
            Client c = doc.toObject(Client.class);
            if (c != null) {
                c.setId(doc.getId());
                list.add(c);
            }
        }
        adapter.updateData(list);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}