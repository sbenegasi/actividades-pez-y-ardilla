package com.pezardilla.actividades.ui.actividades;

import androidx.fragment.app.Fragment;

public class ActividadesFragment extends Fragment {
}
