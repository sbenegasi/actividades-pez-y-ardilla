package com.pezardilla.actividades.ui.actividades;

public class ActividadAdapter
{
}
